var NAVTREEINDEX4 =
{
"namespacesrc_1_1_capa_persistencia.html":[1,0,0,1],
"namespacesrc_1_1_capa_persistencia.html":[0,0,0,1],
"namespacesrc_1_1_capa_presentacio.html":[1,0,0,2],
"namespacesrc_1_1_capa_presentacio.html":[0,0,0,2],
"namespacesrc_1_1_exceptions.html":[0,0,0,3],
"namespacesrc_1_1_exceptions.html":[1,0,0,3],
"pages.html":[]
};
