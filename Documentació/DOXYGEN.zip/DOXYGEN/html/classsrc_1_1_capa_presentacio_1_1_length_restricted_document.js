var classsrc_1_1_capa_presentacio_1_1_length_restricted_document =
[
    [ "LengthRestrictedDocument", "classsrc_1_1_capa_presentacio_1_1_length_restricted_document.html#a8d9492b135be6f4134b18fbfb4e226c6", null ],
    [ "insertString", "classsrc_1_1_capa_presentacio_1_1_length_restricted_document.html#af3367492f6291df06ac8dfb2a8055802", null ],
    [ "limit", "classsrc_1_1_capa_presentacio_1_1_length_restricted_document.html#a571fc9faacd25acdd54ed70d231939bf", null ]
];