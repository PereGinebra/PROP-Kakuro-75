var classsrc_1_1_exceptions_1_1_custom_exception =
[
    [ "CustomException", "classsrc_1_1_exceptions_1_1_custom_exception.html#ad0342e8bb03ac8b0679eaf15404080a3", null ],
    [ "CustomException", "classsrc_1_1_exceptions_1_1_custom_exception.html#ac00c058415f343d199b8330a3d98dbec", null ]
];