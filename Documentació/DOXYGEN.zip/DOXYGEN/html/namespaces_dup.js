var namespaces_dup =
[
    [ "src", "namespacesrc.html", "namespacesrc" ]
];