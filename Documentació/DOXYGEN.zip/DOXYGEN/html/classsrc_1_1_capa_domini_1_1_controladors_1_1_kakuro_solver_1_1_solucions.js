var classsrc_1_1_capa_domini_1_1_controladors_1_1_kakuro_solver_1_1_solucions =
[
    [ "num", "classsrc_1_1_capa_domini_1_1_controladors_1_1_kakuro_solver_1_1_solucions.html#a4c9b58239904269dc942ebbc2df30e29", null ]
];