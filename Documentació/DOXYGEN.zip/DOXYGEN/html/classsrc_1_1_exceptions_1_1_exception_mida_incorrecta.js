var classsrc_1_1_exceptions_1_1_exception_mida_incorrecta =
[
    [ "getMessage", "classsrc_1_1_exceptions_1_1_exception_mida_incorrecta.html#a7aa3b67ee177e7235277c6ba75de32f2", null ]
];