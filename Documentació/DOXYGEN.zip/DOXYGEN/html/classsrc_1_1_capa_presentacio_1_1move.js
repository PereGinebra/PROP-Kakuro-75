var classsrc_1_1_capa_presentacio_1_1move =
[
    [ "move", "classsrc_1_1_capa_presentacio_1_1move.html#afbd69191f5e72816c52abf1a9ba018a2", null ],
    [ "move", "classsrc_1_1_capa_presentacio_1_1move.html#a6fc69f5b7b9e478ed5726eb2ab41cfc1", null ],
    [ "getCol", "classsrc_1_1_capa_presentacio_1_1move.html#a45a73a2f3e43daba607d208079ac6d06", null ],
    [ "getFila", "classsrc_1_1_capa_presentacio_1_1move.html#abd1d022dc65d7ee38d9e025b8fb11fcb", null ],
    [ "getVal", "classsrc_1_1_capa_presentacio_1_1move.html#a08514c2731dfc4529e1c59fa35c3ce60", null ],
    [ "i", "classsrc_1_1_capa_presentacio_1_1move.html#af4f52636d0ef1aefc962e8cde743b1cb", null ],
    [ "j", "classsrc_1_1_capa_presentacio_1_1move.html#a9c8a0fe1f6f3bae5be2ad46d1c7561f3", null ],
    [ "val", "classsrc_1_1_capa_presentacio_1_1move.html#a537c31a46396c0a0b8a69cc8dcc01e10", null ]
];