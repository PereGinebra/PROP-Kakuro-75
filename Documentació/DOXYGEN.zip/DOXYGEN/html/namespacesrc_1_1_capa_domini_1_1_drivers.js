var namespacesrc_1_1_capa_domini_1_1_drivers =
[
    [ "DriverCasella", "classsrc_1_1_capa_domini_1_1_drivers_1_1_driver_casella.html", "classsrc_1_1_capa_domini_1_1_drivers_1_1_driver_casella" ],
    [ "DriverCtrlDomain", "classsrc_1_1_capa_domini_1_1_drivers_1_1_driver_ctrl_domain.html", "classsrc_1_1_capa_domini_1_1_drivers_1_1_driver_ctrl_domain" ],
    [ "DriverKakuroSolver", "classsrc_1_1_capa_domini_1_1_drivers_1_1_driver_kakuro_solver.html", "classsrc_1_1_capa_domini_1_1_drivers_1_1_driver_kakuro_solver" ],
    [ "DriverPartida", "classsrc_1_1_capa_domini_1_1_drivers_1_1_driver_partida.html", "classsrc_1_1_capa_domini_1_1_drivers_1_1_driver_partida" ],
    [ "DriverTaulell", "classsrc_1_1_capa_domini_1_1_drivers_1_1_driver_taulell.html", "classsrc_1_1_capa_domini_1_1_drivers_1_1_driver_taulell" ]
];