var classsrc_1_1_exceptions_1_1_exception_dimensions_taulell_errones =
[
    [ "getMessage", "classsrc_1_1_exceptions_1_1_exception_dimensions_taulell_errones.html#a59f71ecdb2f92a4d4e9f2a76a1a78caa", null ]
];