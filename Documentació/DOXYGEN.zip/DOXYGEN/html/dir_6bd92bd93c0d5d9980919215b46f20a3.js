var dir_6bd92bd93c0d5d9980919215b46f20a3 =
[
    [ "CustomException.java", "_custom_exception_8java.html", [
      [ "CustomException", "classsrc_1_1_exceptions_1_1_custom_exception.html", "classsrc_1_1_exceptions_1_1_custom_exception" ]
    ] ],
    [ "ExceptionCasellaNoModificable.java", "_exception_casella_no_modificable_8java.html", [
      [ "ExceptionCasellaNoModificable", "classsrc_1_1_exceptions_1_1_exception_casella_no_modificable.html", "classsrc_1_1_exceptions_1_1_exception_casella_no_modificable" ]
    ] ],
    [ "ExceptionDificultatErronea.java", "_exception_dificultat_erronea_8java.html", [
      [ "ExceptionDificultatErronea", "classsrc_1_1_exceptions_1_1_exception_dificultat_erronea.html", "classsrc_1_1_exceptions_1_1_exception_dificultat_erronea" ]
    ] ],
    [ "ExceptionDimensionsTaulellErrones.java", "_exception_dimensions_taulell_errones_8java.html", [
      [ "ExceptionDimensionsTaulellErrones", "classsrc_1_1_exceptions_1_1_exception_dimensions_taulell_errones.html", "classsrc_1_1_exceptions_1_1_exception_dimensions_taulell_errones" ]
    ] ],
    [ "ExceptionMidaIncorrecta.java", "_exception_mida_incorrecta_8java.html", [
      [ "ExceptionMidaIncorrecta", "classsrc_1_1_exceptions_1_1_exception_mida_incorrecta.html", "classsrc_1_1_exceptions_1_1_exception_mida_incorrecta" ]
    ] ],
    [ "ExceptionNoExisteixPartida.java", "_exception_no_existeix_partida_8java.html", [
      [ "ExceptionNoExisteixPartida", "classsrc_1_1_exceptions_1_1_exception_no_existeix_partida.html", "classsrc_1_1_exceptions_1_1_exception_no_existeix_partida" ]
    ] ],
    [ "ExceptionNoExisteixTaulell.java", "_exception_no_existeix_taulell_8java.html", [
      [ "ExceptionNoExisteixTaulell", "classsrc_1_1_exceptions_1_1_exception_no_existeix_taulell.html", "classsrc_1_1_exceptions_1_1_exception_no_existeix_taulell" ]
    ] ],
    [ "ExceptionPosicioNoValida.java", "_exception_posicio_no_valida_8java.html", [
      [ "ExceptionPosicioNoValida", "classsrc_1_1_exceptions_1_1_exception_posicio_no_valida.html", "classsrc_1_1_exceptions_1_1_exception_posicio_no_valida" ]
    ] ],
    [ "ExceptionStringBuidaInput.java", "_exception_string_buida_input_8java.html", [
      [ "ExceptionStringBuidaInput", "classsrc_1_1_exceptions_1_1_exception_string_buida_input.html", "classsrc_1_1_exceptions_1_1_exception_string_buida_input" ]
    ] ],
    [ "ExceptionTaulellNoValid.java", "_exception_taulell_no_valid_8java.html", [
      [ "ExceptionTaulellNoValid", "classsrc_1_1_exceptions_1_1_exception_taulell_no_valid.html", "classsrc_1_1_exceptions_1_1_exception_taulell_no_valid" ]
    ] ],
    [ "ExceptionTaulellSenseSolucio.java", "_exception_taulell_sense_solucio_8java.html", [
      [ "ExceptionTaulellSenseSolucio", "classsrc_1_1_exceptions_1_1_exception_taulell_sense_solucio.html", "classsrc_1_1_exceptions_1_1_exception_taulell_sense_solucio" ]
    ] ],
    [ "ExceptionValorForaRang.java", "_exception_valor_fora_rang_8java.html", [
      [ "ExceptionValorForaRang", "classsrc_1_1_exceptions_1_1_exception_valor_fora_rang.html", "classsrc_1_1_exceptions_1_1_exception_valor_fora_rang" ]
    ] ],
    [ "ExceptionValorNoValid.java", "_exception_valor_no_valid_8java.html", [
      [ "ExceptionValorNoValid", "classsrc_1_1_exceptions_1_1_exception_valor_no_valid.html", "classsrc_1_1_exceptions_1_1_exception_valor_no_valid" ]
    ] ],
    [ "ExeptionNoExisteixUsuari.java", "_exeption_no_existeix_usuari_8java.html", [
      [ "ExeptionNoExisteixUsuari", "classsrc_1_1_exceptions_1_1_exeption_no_existeix_usuari.html", "classsrc_1_1_exceptions_1_1_exeption_no_existeix_usuari" ]
    ] ]
];