var classsrc_1_1_exceptions_1_1_exception_casella_no_modificable =
[
    [ "getMessage", "classsrc_1_1_exceptions_1_1_exception_casella_no_modificable.html#aadea409b119427e5dbf20ee97f13b84f", null ]
];