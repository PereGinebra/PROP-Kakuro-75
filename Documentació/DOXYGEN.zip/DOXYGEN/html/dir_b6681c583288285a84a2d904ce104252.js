var dir_b6681c583288285a84a2d904ce104252 =
[
    [ "Casella.java", "_casella_8java.html", [
      [ "Casella", "classsrc_1_1_capa_domini_1_1_classes_1_1_casella.html", "classsrc_1_1_capa_domini_1_1_classes_1_1_casella" ]
    ] ],
    [ "CasellaBlanca.java", "_casella_blanca_8java.html", [
      [ "CasellaBlanca", "classsrc_1_1_capa_domini_1_1_classes_1_1_casella_blanca.html", "classsrc_1_1_capa_domini_1_1_classes_1_1_casella_blanca" ]
    ] ],
    [ "CasellaNegra.java", "_casella_negra_8java.html", [
      [ "CasellaNegra", "classsrc_1_1_capa_domini_1_1_classes_1_1_casella_negra.html", "classsrc_1_1_capa_domini_1_1_classes_1_1_casella_negra" ]
    ] ],
    [ "CasellaSuma.java", "_casella_suma_8java.html", [
      [ "CasellaSuma", "classsrc_1_1_capa_domini_1_1_classes_1_1_casella_suma.html", "classsrc_1_1_capa_domini_1_1_classes_1_1_casella_suma" ]
    ] ],
    [ "Partida.java", "_partida_8java.html", [
      [ "Partida", "classsrc_1_1_capa_domini_1_1_classes_1_1_partida.html", "classsrc_1_1_capa_domini_1_1_classes_1_1_partida" ]
    ] ],
    [ "Taulell.java", "_taulell_8java.html", [
      [ "Taulell", "classsrc_1_1_capa_domini_1_1_classes_1_1_taulell.html", "classsrc_1_1_capa_domini_1_1_classes_1_1_taulell" ]
    ] ],
    [ "Usuario.java", "_usuario_8java_source.html", null ]
];