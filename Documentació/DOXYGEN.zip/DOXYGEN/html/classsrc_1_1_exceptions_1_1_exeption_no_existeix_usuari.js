var classsrc_1_1_exceptions_1_1_exeption_no_existeix_usuari =
[
    [ "getMessage", "classsrc_1_1_exceptions_1_1_exeption_no_existeix_usuari.html#a3c7d5303048d2901ea1354b255721405", null ]
];