var classsrc_1_1_capa_presentacio_1_1_vista_crear_manualment =
[
    [ "VistaCrearManualment", "classsrc_1_1_capa_presentacio_1_1_vista_crear_manualment.html#a5fe6e947af1fe70fc184d3c02d3bff7a", null ],
    [ "initComponents", "classsrc_1_1_capa_presentacio_1_1_vista_crear_manualment.html#a29281c0379fafa6b65b84fef173be408", null ],
    [ "playActionPerformed", "classsrc_1_1_capa_presentacio_1_1_vista_crear_manualment.html#acaa3589597ef1c3d9cce5d30a48a32ca", null ],
    [ "returnmenuActionPerformed", "classsrc_1_1_capa_presentacio_1_1_vista_crear_manualment.html#a37bfa3cf4fe84fcb5a2e5ae3b478f5be", null ],
    [ "sliderColumnsStateChanged", "classsrc_1_1_capa_presentacio_1_1_vista_crear_manualment.html#aadf30934f587b5f501b352a782f646f4", null ],
    [ "sliderRowStateChanged", "classsrc_1_1_capa_presentacio_1_1_vista_crear_manualment.html#a6d959861a6da636cd41aa54e5d644669", null ],
    [ "cp", "classsrc_1_1_capa_presentacio_1_1_vista_crear_manualment.html#a20f7a0e100228108a39448cb8d6374c1", null ],
    [ "error", "classsrc_1_1_capa_presentacio_1_1_vista_crear_manualment.html#a46acbf66b1f3aeb9bbb1c516fe4e51d1", null ],
    [ "jLabel2", "classsrc_1_1_capa_presentacio_1_1_vista_crear_manualment.html#afeebdc0a99d7d120096f5c40b5b127a0", null ],
    [ "jLabel4", "classsrc_1_1_capa_presentacio_1_1_vista_crear_manualment.html#a806b3bd3181bd9f11f63cf4b1ae16029", null ],
    [ "jPanel1", "classsrc_1_1_capa_presentacio_1_1_vista_crear_manualment.html#ae596746e041b2c68ce46caba482a6fd9", null ],
    [ "jScrollPane1", "classsrc_1_1_capa_presentacio_1_1_vista_crear_manualment.html#a392cdcf4547815a13a8a9c54e065731e", null ],
    [ "labelcolumnes", "classsrc_1_1_capa_presentacio_1_1_vista_crear_manualment.html#aebcd6e8c1a902d6e0d92f1051e028348", null ],
    [ "labelfiles", "classsrc_1_1_capa_presentacio_1_1_vista_crear_manualment.html#af2d6908f36556aeeb64ccf55f98eb2c8", null ],
    [ "parent", "classsrc_1_1_capa_presentacio_1_1_vista_crear_manualment.html#a158cdc53e706061d7566f392d67dd258", null ],
    [ "play", "classsrc_1_1_capa_presentacio_1_1_vista_crear_manualment.html#a5f74858e3ff6c983cc265368c1122128", null ],
    [ "returnmenu", "classsrc_1_1_capa_presentacio_1_1_vista_crear_manualment.html#aa0355ef8139805af4c5f390c65f1fae1", null ],
    [ "sliderColumns", "classsrc_1_1_capa_presentacio_1_1_vista_crear_manualment.html#a53664b87c0c6831a03a17337a644e974", null ],
    [ "sliderRow", "classsrc_1_1_capa_presentacio_1_1_vista_crear_manualment.html#a1bc458531b18c96866a0845fe3e2ef78", null ],
    [ "textkakuro", "classsrc_1_1_capa_presentacio_1_1_vista_crear_manualment.html#a2217b8d76ddc9af65694f41756d9faf9", null ]
];