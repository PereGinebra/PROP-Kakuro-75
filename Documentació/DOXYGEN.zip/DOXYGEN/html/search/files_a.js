var searchData=
[
  ['usuari_2ejava_719',['Usuari.java',['../_usuari_8java.html',1,'']]]
];
