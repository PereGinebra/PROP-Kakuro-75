var searchData=
[
  ['exceptioncasellanomodificable_620',['ExceptionCasellaNoModificable',['../classsrc_1_1_exceptions_1_1_exception_casella_no_modificable.html',1,'src::Exceptions']]],
  ['exceptiondificultaterronea_621',['ExceptionDificultatErronea',['../classsrc_1_1_exceptions_1_1_exception_dificultat_erronea.html',1,'src::Exceptions']]],
  ['exceptiondimensionstaulellerrones_622',['ExceptionDimensionsTaulellErrones',['../classsrc_1_1_exceptions_1_1_exception_dimensions_taulell_errones.html',1,'src::Exceptions']]],
  ['exceptionmidaincorrecta_623',['ExceptionMidaIncorrecta',['../classsrc_1_1_exceptions_1_1_exception_mida_incorrecta.html',1,'src::Exceptions']]],
  ['exceptionnoexisteixpartida_624',['ExceptionNoExisteixPartida',['../classsrc_1_1_exceptions_1_1_exception_no_existeix_partida.html',1,'src::Exceptions']]],
  ['exceptionnoexisteixtaulell_625',['ExceptionNoExisteixTaulell',['../classsrc_1_1_exceptions_1_1_exception_no_existeix_taulell.html',1,'src::Exceptions']]],
  ['exceptionposicionovalida_626',['ExceptionPosicioNoValida',['../classsrc_1_1_exceptions_1_1_exception_posicio_no_valida.html',1,'src::Exceptions']]],
  ['exceptionstringbuidainput_627',['ExceptionStringBuidaInput',['../classsrc_1_1_exceptions_1_1_exception_string_buida_input.html',1,'src::Exceptions']]],
  ['exceptiontaulellnovalid_628',['ExceptionTaulellNoValid',['../classsrc_1_1_exceptions_1_1_exception_taulell_no_valid.html',1,'src::Exceptions']]],
  ['exceptiontaulellsensesolucio_629',['ExceptionTaulellSenseSolucio',['../classsrc_1_1_exceptions_1_1_exception_taulell_sense_solucio.html',1,'src::Exceptions']]],
  ['exceptionvalorforarang_630',['ExceptionValorForaRang',['../classsrc_1_1_exceptions_1_1_exception_valor_fora_rang.html',1,'src::Exceptions']]],
  ['exceptionvalornovalid_631',['ExceptionValorNoValid',['../classsrc_1_1_exceptions_1_1_exception_valor_no_valid.html',1,'src::Exceptions']]],
  ['exeptionnoexisteixusuari_632',['ExeptionNoExisteixUsuari',['../classsrc_1_1_exceptions_1_1_exeption_no_existeix_usuari.html',1,'src::Exceptions']]]
];
