var searchData=
[
  ['randomkakuro_644',['RandomKakuro',['../classsrc_1_1_capa_domini_1_1_controladors_1_1_random_kakuro.html',1,'src::CapaDomini::Controladors']]],
  ['rankingglobal_645',['RankingGlobal',['../classsrc_1_1_capa_domini_1_1_classes_1_1_ranking_global.html',1,'src::CapaDomini::Classes']]],
  ['rankingtaulell_646',['RankingTaulell',['../classsrc_1_1_capa_domini_1_1_classes_1_1_ranking_taulell.html',1,'src::CapaDomini::Classes']]]
];
