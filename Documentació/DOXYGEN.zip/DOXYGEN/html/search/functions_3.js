var searchData=
[
  ['defaultkakuro_806',['DefaultKakuro',['../classsrc_1_1_capa_domini_1_1_controladors_1_1_random_kakuro.html#a339f9ad7619869215d5899f4458a9d0e',1,'src::CapaDomini::Controladors::RandomKakuro']]],
  ['deletekakuro_807',['deleteKakuro',['../classsrc_1_1_capa_persistencia_1_1_ctrl_persistencia.html#a9b0231c467134752d234396e52b11bd5',1,'src::CapaPersistencia::CtrlPersistencia']]],
  ['deletepartidaencurs_808',['deletePartidaEnCurs',['../classsrc_1_1_capa_persistencia_1_1_ctrl_persistencia.html#a409e50c7a9951bbfc21f88035a6a6b11',1,'src::CapaPersistencia::CtrlPersistencia']]],
  ['demanarajuda_809',['demanarAjuda',['../classsrc_1_1_capa_domini_1_1_classes_1_1_partida.html#ac99bd8bbdff75a5a94fe4744073801e7',1,'src.CapaDomini.Classes.Partida.demanarAjuda()'],['../classsrc_1_1_capa_domini_1_1_controladors_1_1_ctrl_domain.html#ad03bbeeb20b48d77227ca462ea45cf76',1,'src.CapaDomini.Controladors.CtrlDomain.demanarAjuda()'],['../classsrc_1_1_capa_domini_1_1_controladors_1_1_ctrl_partida.html#a1fcf726b85a7f4e54ade64db60713225',1,'src.CapaDomini.Controladors.CtrlPartida.demanarAjuda()'],['../classsrc_1_1_capa_presentacio_1_1_ctrl_presentacio.html#a782a04ec4e4e5e52081306b71f1f1e60',1,'src.CapaPresentacio.CtrlPresentacio.demanarAjuda()']]],
  ['driverctrldomain_810',['DriverCtrlDomain',['../classsrc_1_1_capa_domini_1_1_drivers_1_1_driver_ctrl_domain.html#a523173d060823e6522be719622dfdd6d',1,'src::CapaDomini::Drivers::DriverCtrlDomain']]],
  ['driverkakurosolver_811',['DriverKakuroSolver',['../classsrc_1_1_capa_domini_1_1_drivers_1_1_driver_kakuro_solver.html#a5b5edc1761cc8ef1e7e49b2e1c4dfa32',1,'src::CapaDomini::Drivers::DriverKakuroSolver']]],
  ['driverpartida_812',['DriverPartida',['../classsrc_1_1_capa_domini_1_1_drivers_1_1_driver_partida.html#a42c78ad3bfbc0d6d79ce40da6ef9a88a',1,'src::CapaDomini::Drivers::DriverPartida']]],
  ['drivertaulell_813',['DriverTaulell',['../classsrc_1_1_capa_domini_1_1_drivers_1_1_driver_taulell.html#a389aff93aedcf20a92fd6c41a8ca5fba',1,'src::CapaDomini::Drivers::DriverTaulell']]]
];
