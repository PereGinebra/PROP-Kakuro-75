var searchData=
[
  ['quitbutton_441',['QuitButton',['../classsrc_1_1_capa_presentacio_1_1_vista_partida.html#a7c504451a100910e6d19bfe2c4f7ac36',1,'src::CapaPresentacio::VistaPartida']]],
  ['quitbuttonactionperformed_442',['QuitButtonActionPerformed',['../classsrc_1_1_capa_presentacio_1_1_vista_partida.html#ab08c78c6f1491d935f742b6c67ad830a',1,'src::CapaPresentacio::VistaPartida']]]
];
