var searchData=
[
  ['quitbuttonactionperformed_959',['QuitButtonActionPerformed',['../classsrc_1_1_capa_presentacio_1_1_vista_partida.html#ab08c78c6f1491d935f742b6c67ad830a',1,'src::CapaPresentacio::VistaPartida']]]
];
