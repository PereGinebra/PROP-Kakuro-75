var searchData=
[
  ['main_636',['Main',['../classsrc_1_1_main.html',1,'src']]],
  ['menuprincipal_637',['MenuPrincipal',['../classsrc_1_1_capa_presentacio_1_1_menu_principal.html',1,'src::CapaPresentacio']]],
  ['move_638',['move',['../classsrc_1_1_capa_presentacio_1_1move.html',1,'src::CapaPresentacio']]]
];
