var searchData=
[
  ['usuari_650',['Usuari',['../classsrc_1_1_capa_domini_1_1_classes_1_1_usuari.html',1,'src::CapaDomini::Classes']]]
];
