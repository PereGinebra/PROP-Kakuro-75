var searchData=
[
  ['pairii_639',['PairII',['../classsrc_1_1_capa_domini_1_1_utils_1_1_pair_i_i.html',1,'src::CapaDomini::Utils']]],
  ['pairsb_640',['PairSB',['../classsrc_1_1_capa_domini_1_1_utils_1_1_pair_s_b.html',1,'src::CapaDomini::Utils']]],
  ['pantallaprincipal_641',['PantallaPrincipal',['../classsrc_1_1_capa_presentacio_1_1_pantalla_principal.html',1,'src::CapaPresentacio']]],
  ['partida_642',['Partida',['../classsrc_1_1_capa_domini_1_1_classes_1_1_partida.html',1,'src::CapaDomini::Classes']]],
  ['permutacions_643',['Permutacions',['../classsrc_1_1_capa_domini_1_1_utils_1_1_permutacions.html',1,'src::CapaDomini::Utils']]]
];
