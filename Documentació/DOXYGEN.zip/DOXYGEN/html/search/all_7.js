var searchData=
[
  ['h_303',['h',['../classsrc_1_1_capa_presentacio_1_1_vista_partida.html#ad60e7b08ce6e8f00c82ccdf61d59a7c6',1,'src::CapaPresentacio::VistaPartida']]],
  ['hiharepetits_304',['hiHaRepetits',['../classsrc_1_1_capa_domini_1_1_classes_1_1_partida.html#ae18be80bca34e96b03f8978f558cb20c',1,'src.CapaDomini.Classes.Partida.hiHaRepetits()'],['../classsrc_1_1_capa_domini_1_1_controladors_1_1_ctrl_partida.html#ad16dccfc2813600ce92c35385539c14c',1,'src.CapaDomini.Controladors.CtrlPartida.hiHaRepetits()']]],
  ['hintbutton_305',['HintButton',['../classsrc_1_1_capa_presentacio_1_1_vista_partida.html#a4a28ece95dcbefb8931432b72fef118d',1,'src::CapaPresentacio::VistaPartida']]],
  ['hintbuttonactionperformed_306',['HintButtonActionPerformed',['../classsrc_1_1_capa_presentacio_1_1_vista_partida.html#a3ca05a68bb528af1dac92120bedaa215',1,'src::CapaPresentacio::VistaPartida']]],
  ['hourlabel_307',['hourLabel',['../classsrc_1_1_capa_presentacio_1_1_vista_partida.html#abdd45a7bdee93fbe1aedfadae915fb77',1,'src::CapaPresentacio::VistaPartida']]]
];
