var searchData=
[
  ['s_1201',['s',['../classsrc_1_1_capa_presentacio_1_1_vista_partida.html#aeb19db14d66c412993fb88814376869b',1,'src::CapaPresentacio::VistaPartida']]],
  ['savebutton_1202',['SaveButton',['../classsrc_1_1_capa_presentacio_1_1_vista_partida.html#a9e4c85d7813e4713628abef0894c50a0',1,'src::CapaPresentacio::VistaPartida']]],
  ['savegame_1203',['SaveGame',['../classsrc_1_1_capa_presentacio_1_1_vista_partida.html#aadf6d457f22542408b33d5e58e5b2e40',1,'src::CapaPresentacio::VistaPartida']]],
  ['secondlabel_1204',['secondLabel',['../classsrc_1_1_capa_presentacio_1_1_vista_partida.html#a3cff52246eff07d3769e3e0bd394bbe3',1,'src::CapaPresentacio::VistaPartida']]],
  ['slidercolumns_1205',['sliderColumns',['../classsrc_1_1_capa_presentacio_1_1_vista_crear_manualment.html#a53664b87c0c6831a03a17337a644e974',1,'src.CapaPresentacio.VistaCrearManualment.sliderColumns()'],['../classsrc_1_1_capa_presentacio_1_1_vista_autogenerar.html#aecc5befbbabb57afd21935e1663b8f4c',1,'src.CapaPresentacio.VistaAutogenerar.SliderColumns()']]],
  ['sliderrow_1206',['sliderRow',['../classsrc_1_1_capa_presentacio_1_1_vista_crear_manualment.html#a1bc458531b18c96866a0845fe3e2ef78',1,'src::CapaPresentacio::VistaCrearManualment']]],
  ['sliderrows_1207',['SliderRows',['../classsrc_1_1_capa_presentacio_1_1_vista_autogenerar.html#a23dfd031e82b3784e66c92d1ae6f0255',1,'src::CapaPresentacio::VistaAutogenerar']]],
  ['solvekakurobutton_1208',['SolveKakuroButton',['../classsrc_1_1_capa_presentacio_1_1_vista_partida.html#acf378eae83aea39320f82ca6fb1a079c',1,'src::CapaPresentacio::VistaPartida']]],
  ['solver_1209',['solver',['../classsrc_1_1_capa_domini_1_1_controladors_1_1_ctrl_domain.html#ac9181ceab3f43e2cd1289fb3f9ee41e3',1,'src.CapaDomini.Controladors.CtrlDomain.solver()'],['../classsrc_1_1_capa_domini_1_1_drivers_1_1_driver_kakuro_solver.html#a09f920d2e66f8c7e664c6c2f6112e3a9',1,'src.CapaDomini.Drivers.DriverKakuroSolver.solver()']]],
  ['sortir_1210',['sortir',['../classsrc_1_1_capa_presentacio_1_1_vista_ranking_global.html#a37fca2fc19b4f6dd757fd90a563ec8bd',1,'src::CapaPresentacio::VistaRankingGlobal']]],
  ['sumacol_1211',['sumaCol',['../classsrc_1_1_capa_domini_1_1_classes_1_1_casella_suma.html#a90d3dc10ed8f1fb5a5bdf5ecb7cef2bd',1,'src::CapaDomini::Classes::CasellaSuma']]],
  ['sumafila_1212',['sumaFila',['../classsrc_1_1_capa_domini_1_1_classes_1_1_casella_suma.html#a1c71f268fc8af46dc7b4722b8476deee',1,'src::CapaDomini::Classes::CasellaSuma']]]
];
