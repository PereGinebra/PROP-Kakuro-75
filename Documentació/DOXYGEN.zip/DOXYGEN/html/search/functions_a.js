var searchData=
[
  ['kakurosolver_921',['KakuroSolver',['../classsrc_1_1_capa_domini_1_1_controladors_1_1_kakuro_solver.html#aafb36cb8f9ba469e4a84e8480b3a0e27',1,'src.CapaDomini.Controladors.KakuroSolver.KakuroSolver()'],['../classsrc_1_1_capa_domini_1_1_controladors_1_1_kakuro_solver.html#a1b542ca0475507952e40d459a36c3d7f',1,'src.CapaDomini.Controladors.KakuroSolver.KakuroSolver(Taulell t)']]]
];
