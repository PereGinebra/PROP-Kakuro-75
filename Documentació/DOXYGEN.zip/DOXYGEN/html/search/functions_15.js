var searchData=
[
  ['validarkakuro_1026',['validarKakuro',['../classsrc_1_1_capa_domini_1_1_controladors_1_1_ctrl_domain.html#a8cd807626c6889691fb8d264b160ab7e',1,'src.CapaDomini.Controladors.CtrlDomain.validarKakuro()'],['../classsrc_1_1_capa_presentacio_1_1_ctrl_presentacio.html#aa3fec6f37a45583aba933564f2ebc4fe',1,'src.CapaPresentacio.CtrlPresentacio.validarKakuro()']]],
  ['valorpossible_1027',['valorPossible',['../classsrc_1_1_capa_domini_1_1_controladors_1_1_kakuro_solver.html#a0d954e796dc36834d32b4251d497737f',1,'src.CapaDomini.Controladors.KakuroSolver.valorPossible()'],['../classsrc_1_1_capa_domini_1_1_controladors_1_1_random_kakuro.html#a357594cf78f2b9e5a0f6d12e19a381b3',1,'src.CapaDomini.Controladors.RandomKakuro.valorPossible()']]],
  ['valorspossiblesdeunacasella_1028',['valorsPossiblesDeUnaCasella',['../classsrc_1_1_capa_domini_1_1_utils_1_1_permutacions.html#a1475afedc2b36a437ffaafb746f11ca3',1,'src::CapaDomini::Utils::Permutacions']]],
  ['vistaautogenerar_1029',['VistaAutogenerar',['../classsrc_1_1_capa_presentacio_1_1_vista_autogenerar.html#acfb1c2f15c70f87f65131d20473a53d0',1,'src.CapaPresentacio.VistaAutogenerar.VistaAutogenerar()'],['../classsrc_1_1_capa_presentacio_1_1_vista_autogenerar.html#af9cefc03d49725514d49b85bb9a71321',1,'src.CapaPresentacio.VistaAutogenerar.VistaAutogenerar(javax.swing.JFrame parent, CtrlPresentacio cp)']]],
  ['vistacrearmanualment_1030',['VistaCrearManualment',['../classsrc_1_1_capa_presentacio_1_1_vista_crear_manualment.html#a5fe6e947af1fe70fc184d3c02d3bff7a',1,'src::CapaPresentacio::VistaCrearManualment']]],
  ['vistanewgame_1031',['VistaNewGame',['../classsrc_1_1_capa_presentacio_1_1_vista_new_game.html#a78f140e621f9fbe01225a5e5638d0325',1,'src::CapaPresentacio::VistaNewGame']]],
  ['vistapartida_1032',['VistaPartida',['../classsrc_1_1_capa_presentacio_1_1_vista_partida.html#a4f52ec32641c57a05ef11875ace13357',1,'src::CapaPresentacio::VistaPartida']]],
  ['vistarankingglobal_1033',['VistaRankingGlobal',['../classsrc_1_1_capa_presentacio_1_1_vista_ranking_global.html#af8710c440174eacd8c9c8f9b4bd2491d',1,'src::CapaPresentacio::VistaRankingGlobal']]],
  ['vistarankingpartida_1034',['VistaRankingPartida',['../classsrc_1_1_capa_presentacio_1_1_vista_ranking_partida.html#a70a42af233e6bc764f1db566f41b8f7c',1,'src::CapaPresentacio::VistaRankingPartida']]],
  ['vistaselecciokakuro_1035',['VistaSeleccioKakuro',['../classsrc_1_1_capa_presentacio_1_1_vista_seleccio_kakuro.html#a86d511d8cfb72bdfc04ccee0e0428082',1,'src::CapaPresentacio::VistaSeleccioKakuro']]]
];
