var searchData=
[
  ['hiharepetits_908',['hiHaRepetits',['../classsrc_1_1_capa_domini_1_1_classes_1_1_partida.html#ae18be80bca34e96b03f8978f558cb20c',1,'src.CapaDomini.Classes.Partida.hiHaRepetits()'],['../classsrc_1_1_capa_domini_1_1_controladors_1_1_ctrl_partida.html#ad16dccfc2813600ce92c35385539c14c',1,'src.CapaDomini.Controladors.CtrlPartida.hiHaRepetits()']]],
  ['hintbuttonactionperformed_909',['HintButtonActionPerformed',['../classsrc_1_1_capa_presentacio_1_1_vista_partida.html#a3ca05a68bb528af1dac92120bedaa215',1,'src::CapaPresentacio::VistaPartida']]]
];
