var searchData=
[
  ['vistaautogenerar_651',['VistaAutogenerar',['../classsrc_1_1_capa_presentacio_1_1_vista_autogenerar.html',1,'src::CapaPresentacio']]],
  ['vistacrearmanualment_652',['VistaCrearManualment',['../classsrc_1_1_capa_presentacio_1_1_vista_crear_manualment.html',1,'src::CapaPresentacio']]],
  ['vistanewgame_653',['VistaNewGame',['../classsrc_1_1_capa_presentacio_1_1_vista_new_game.html',1,'src::CapaPresentacio']]],
  ['vistapartida_654',['VistaPartida',['../classsrc_1_1_capa_presentacio_1_1_vista_partida.html',1,'src::CapaPresentacio']]],
  ['vistarankingglobal_655',['VistaRankingGlobal',['../classsrc_1_1_capa_presentacio_1_1_vista_ranking_global.html',1,'src::CapaPresentacio']]],
  ['vistarankingpartida_656',['VistaRankingPartida',['../classsrc_1_1_capa_presentacio_1_1_vista_ranking_partida.html',1,'src::CapaPresentacio']]],
  ['vistaselecciokakuro_657',['VistaSeleccioKakuro',['../classsrc_1_1_capa_presentacio_1_1_vista_seleccio_kakuro.html',1,'src::CapaPresentacio']]]
];
