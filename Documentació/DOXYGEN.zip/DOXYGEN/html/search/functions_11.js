var searchData=
[
  ['randomkakuro_960',['RandomKakuro',['../classsrc_1_1_capa_domini_1_1_controladors_1_1_random_kakuro.html#aa271a63eab3730f0affc5ee2ab1919dd',1,'src.CapaDomini.Controladors.RandomKakuro.RandomKakuro()'],['../classsrc_1_1_capa_domini_1_1_controladors_1_1_random_kakuro.html#a00cfcf3636077b5ef4d1ca75f9e13670',1,'src.CapaDomini.Controladors.RandomKakuro.RandomKakuro(int nfiles, int ncolumnes, String tdificultat)']]],
  ['rankingglobal_961',['RankingGlobal',['../classsrc_1_1_capa_domini_1_1_classes_1_1_ranking_global.html#abe8b83c523373c905b101cbd39012520',1,'src::CapaDomini::Classes::RankingGlobal']]],
  ['rankingtaulell_962',['RankingTaulell',['../classsrc_1_1_capa_domini_1_1_classes_1_1_ranking_taulell.html#a7f5e51eed4ec253996c66c55337a9618',1,'src.CapaDomini.Classes.RankingTaulell.RankingTaulell()'],['../classsrc_1_1_capa_domini_1_1_classes_1_1_ranking_taulell.html#a5c87914af8a69d2721b3cd20ab578268',1,'src.CapaDomini.Classes.RankingTaulell.RankingTaulell(ArrayList&lt; AbstractMap.SimpleEntry&lt; String, Long &gt;&gt; r)']]],
  ['rankingusuaris_963',['rankingUsuaris',['../classsrc_1_1_capa_domini_1_1_controladors_1_1_ctrl_domain.html#a5961a705d277a2277d62f695db9c7591',1,'src.CapaDomini.Controladors.CtrlDomain.rankingUsuaris()'],['../classsrc_1_1_capa_presentacio_1_1_ctrl_presentacio.html#ae2a4aed759cb44e7cd56c293dce090dc',1,'src.CapaPresentacio.CtrlPresentacio.rankingUsuaris()']]],
  ['recinsert_964',['recInsert',['../classsrc_1_1_capa_domini_1_1_classes_1_1_ranking_taulell.html#af4ab82a8abbbd4e2ba34de47276b8052',1,'src::CapaDomini::Classes::RankingTaulell']]],
  ['redobuttonactionperformed_965',['RedoButtonActionPerformed',['../classsrc_1_1_capa_presentacio_1_1_vista_partida.html#acb4136047b84507da34ec2a3ac91f82f',1,'src::CapaPresentacio::VistaPartida']]],
  ['resoldrecasella_966',['resoldreCasella',['../classsrc_1_1_capa_domini_1_1_classes_1_1_partida.html#a21b02046ad92f5fc17fcf3afd0c850f7',1,'src::CapaDomini::Classes::Partida']]],
  ['returnmenuactionperformed_967',['returnmenuActionPerformed',['../classsrc_1_1_capa_presentacio_1_1_vista_crear_manualment.html#a37bfa3cf4fe84fcb5a2e5ae3b478f5be',1,'src::CapaPresentacio::VistaCrearManualment']]],
  ['run_968',['run',['../classsrc_1_1_capa_presentacio_1_1_ctrl_presentacio.html#a5db30fbe1efc508b19462dab6df44c11',1,'src::CapaPresentacio::CtrlPresentacio']]]
];
