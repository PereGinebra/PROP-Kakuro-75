var searchData=
[
  ['kakurogenerat_343',['KakuroGenerat',['../classsrc_1_1_capa_domini_1_1_controladors_1_1_random_kakuro.html#ae818214b5bb20e70b27b84f6f7f91f3f',1,'src::CapaDomini::Controladors::RandomKakuro']]],
  ['kakurosolver_344',['KakuroSolver',['../classsrc_1_1_capa_domini_1_1_controladors_1_1_kakuro_solver.html',1,'src.CapaDomini.Controladors.KakuroSolver'],['../classsrc_1_1_capa_domini_1_1_controladors_1_1_kakuro_solver.html#aafb36cb8f9ba469e4a84e8480b3a0e27',1,'src.CapaDomini.Controladors.KakuroSolver.KakuroSolver()'],['../classsrc_1_1_capa_domini_1_1_controladors_1_1_kakuro_solver.html#a1b542ca0475507952e40d459a36c3d7f',1,'src.CapaDomini.Controladors.KakuroSolver.KakuroSolver(Taulell t)']]],
  ['kakurosolver_2ejava_345',['KakuroSolver.java',['../_kakuro_solver_8java.html',1,'']]]
];
