var searchData=
[
  ['jbutton1actionperformed_919',['jButton1ActionPerformed',['../classsrc_1_1_capa_presentacio_1_1_vista_ranking_partida.html#ad2f08406c54a07052e144dc6f08e60d2',1,'src::CapaPresentacio::VistaRankingPartida']]],
  ['jugar_920',['jugar',['../classsrc_1_1_capa_domini_1_1_controladors_1_1_ctrl_domain.html#ac82aed02e397c1fedc6b0ef0edbc215d',1,'src.CapaDomini.Controladors.CtrlDomain.jugar()'],['../classsrc_1_1_capa_domini_1_1_drivers_1_1_driver_ctrl_domain.html#a04e6e0eacda7822117c291ba8ce2d15f',1,'src.CapaDomini.Drivers.DriverCtrlDomain.jugar()']]]
];
