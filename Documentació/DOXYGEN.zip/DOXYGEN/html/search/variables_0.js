var searchData=
[
  ['acabada_1036',['acabada',['../classsrc_1_1_capa_domini_1_1_classes_1_1_partida.html#a96846a9386496dd4159afe7d182baea6',1,'src::CapaDomini::Classes::Partida']]]
];
