var searchData=
[
  ['randomizer_1193',['randomizer',['../classsrc_1_1_capa_domini_1_1_controladors_1_1_ctrl_domain.html#a70c682224191f1b742ad55742f244972',1,'src::CapaDomini::Controladors::CtrlDomain']]],
  ['rank_1194',['rank',['../classsrc_1_1_capa_domini_1_1_classes_1_1_ranking_taulell.html#aa93c9bdfed8c9e270f798117c6d6f3b7',1,'src::CapaDomini::Classes::RankingTaulell']]],
  ['ranking_1195',['ranking',['../classsrc_1_1_capa_domini_1_1_classes_1_1_ranking_global.html#af1ffdf0e578b2e7184d4ee5946cdffb9',1,'src.CapaDomini.Classes.RankingGlobal.ranking()'],['../classsrc_1_1_capa_presentacio_1_1_vista_ranking_global.html#abd96ff7847fdeae17c1e9d33c4a5cea9',1,'src.CapaPresentacio.VistaRankingGlobal.ranking()']]],
  ['redoable_1196',['redoable',['../classsrc_1_1_capa_presentacio_1_1_vista_partida.html#ab3c961fb8bf7475a5e6d12f9551dbf33',1,'src::CapaPresentacio::VistaPartida']]],
  ['redobutton_1197',['RedoButton',['../classsrc_1_1_capa_presentacio_1_1_vista_partida.html#af065b777a32eb3d9d7bbacea96754990',1,'src::CapaPresentacio::VistaPartida']]],
  ['returnmenu_1198',['returnmenu',['../classsrc_1_1_capa_presentacio_1_1_vista_crear_manualment.html#aa0355ef8139805af4c5f390c65f1fae1',1,'src::CapaPresentacio::VistaCrearManualment']]],
  ['rg_1199',['RG',['../classsrc_1_1_capa_domini_1_1_controladors_1_1_ctrl_ranking_global.html#af7bffc1682871a460cff6aa4c1f66887',1,'src::CapaDomini::Controladors::CtrlRankingGlobal']]],
  ['right_1200',['right',['../classsrc_1_1_capa_domini_1_1_utils_1_1_pair_i_i.html#a3b230a36fabc6597c462fb1a49b69346',1,'src.CapaDomini.Utils.PairII.right()'],['../classsrc_1_1_capa_domini_1_1_utils_1_1_pair_s_b.html#a27af2f5c81f711f75972cd13fdc8cb2d',1,'src.CapaDomini.Utils.PairSB.right()']]]
];
