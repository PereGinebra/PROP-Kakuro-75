var searchData=
[
  ['taulell_649',['Taulell',['../classsrc_1_1_capa_domini_1_1_classes_1_1_taulell.html',1,'src::CapaDomini::Classes']]]
];
