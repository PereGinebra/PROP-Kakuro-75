var searchData=
[
  ['val_1239',['val',['../classsrc_1_1_capa_presentacio_1_1move.html#a537c31a46396c0a0b8a69cc8dcc01e10',1,'src::CapaPresentacio::move']]],
  ['valor_1240',['valor',['../classsrc_1_1_capa_domini_1_1_classes_1_1_casella.html#a52f218332e6f73f0eef3447e7b5cef85',1,'src::CapaDomini::Classes::Casella']]],
  ['valorspossibles_1241',['valorsPossibles',['../classsrc_1_1_capa_domini_1_1_utils_1_1_permutacions.html#a770c40429e442173ace25cae76c5ebee',1,'src::CapaDomini::Utils::Permutacions']]]
];
