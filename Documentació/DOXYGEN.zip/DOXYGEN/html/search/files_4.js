var searchData=
[
  ['kakurosolver_2ejava_697',['KakuroSolver.java',['../_kakuro_solver_8java.html',1,'']]]
];
