var searchData=
[
  ['signup_647',['SignUp',['../classsrc_1_1_capa_presentacio_1_1_sign_up.html',1,'src::CapaPresentacio']]],
  ['solucions_648',['Solucions',['../classsrc_1_1_capa_domini_1_1_controladors_1_1_kakuro_solver_1_1_solucions.html',1,'src::CapaDomini::Controladors::KakuroSolver']]]
];
