var searchData=
[
  ['kakurosolver_634',['KakuroSolver',['../classsrc_1_1_capa_domini_1_1_controladors_1_1_kakuro_solver.html',1,'src::CapaDomini::Controladors']]]
];
