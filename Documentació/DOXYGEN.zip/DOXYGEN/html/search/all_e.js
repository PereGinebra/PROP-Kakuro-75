var searchData=
[
  ['of_399',['of',['../classsrc_1_1_capa_domini_1_1_utils_1_1_pair_i_i.html#a4ea6d2a84abd867f3f0f35626a06103d',1,'src.CapaDomini.Utils.PairII.of()'],['../classsrc_1_1_capa_domini_1_1_utils_1_1_pair_s_b.html#ae1cfc0d928690febb864b27a5f0b793a',1,'src.CapaDomini.Utils.PairSB.of()']]],
  ['omplircoordnoconfirmades_400',['omplirCoordNoConfirmades',['../classsrc_1_1_capa_domini_1_1_classes_1_1_partida.html#a3e8cf939455c33e8e7d899ce14ebdd85',1,'src::CapaDomini::Classes::Partida']]],
  ['omplirvalors_401',['omplirValors',['../classsrc_1_1_capa_domini_1_1_utils_1_1_permutacions.html#a29e171eb4e1f272c3cdf76e7840809e8',1,'src::CapaDomini::Utils::Permutacions']]]
];
