var searchData=
[
  ['newtaulell_937',['newTaulell',['../classsrc_1_1_capa_presentacio_1_1_ctrl_presentacio.html#a9f86284cfad9d5ebd737bd0e86866c5b',1,'src::CapaPresentacio::CtrlPresentacio']]],
  ['nombrecasellesblanquesspecific_938',['nombreCasellesBlanquesSpecific',['../classsrc_1_1_capa_domini_1_1_classes_1_1_taulell.html#acde7321a22a15542949b9b89fba5b9d4',1,'src::CapaDomini::Classes::Taulell']]],
  ['nomnoukakuro_939',['nomnouKakuro',['../classsrc_1_1_capa_persistencia_1_1_ctrl_persistencia.html#a32456b1af53ce0de531425595771cb0e',1,'src::CapaPersistencia::CtrlPersistencia']]],
  ['nomnousoluciokakuro_940',['nomnouSolucioKakuro',['../classsrc_1_1_capa_persistencia_1_1_ctrl_persistencia.html#a4360d4e330a2419171912c6c7a0e9aee',1,'src::CapaPersistencia::CtrlPersistencia']]],
  ['nompartida_941',['nomPartida',['../classsrc_1_1_capa_persistencia_1_1_ctrl_persistencia.html#a31e473d10c73a431cd98e9bdeb04cde9',1,'src::CapaPersistencia::CtrlPersistencia']]],
  ['normalitzarespai_942',['NormalitzarEspai',['../classsrc_1_1_capa_domini_1_1_utils_1_1_final_variables.html#a10c05ca7f536cd6ae6a63c3874dd0def',1,'src::CapaDomini::Utils::FinalVariables']]],
  ['numsolucions_943',['numSolucions',['../classsrc_1_1_capa_domini_1_1_controladors_1_1_kakuro_solver.html#a2d28d22a1ca17e79da73239b2931930f',1,'src::CapaDomini::Controladors::KakuroSolver']]]
];
