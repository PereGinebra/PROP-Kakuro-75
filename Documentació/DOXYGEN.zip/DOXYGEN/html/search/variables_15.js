var searchData=
[
  ['whitecellpercentdificil_1242',['WhiteCellPercentDificil',['../classsrc_1_1_capa_domini_1_1_utils_1_1_final_variables.html#a7b7ccbbfe3410c13edb0b4346ad14504',1,'src::CapaDomini::Utils::FinalVariables']]],
  ['whitecellpercentfacil_1243',['WhiteCellPercentFacil',['../classsrc_1_1_capa_domini_1_1_utils_1_1_final_variables.html#ad7c8a0ff553c0d2075a8b9ff5d7336bd',1,'src::CapaDomini::Utils::FinalVariables']]],
  ['whitecellpercentmig_1244',['WhiteCellPercentMig',['../classsrc_1_1_capa_domini_1_1_utils_1_1_final_variables.html#a41e41b0f23c9f4540e34b617aadeece3',1,'src::CapaDomini::Utils::FinalVariables']]]
];
