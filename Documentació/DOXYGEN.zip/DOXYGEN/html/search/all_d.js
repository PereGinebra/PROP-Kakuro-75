var searchData=
[
  ['nameuser_387',['nameUser',['../classsrc_1_1_capa_presentacio_1_1_vista_ranking_partida.html#abc44dc52294a121d3a548b3a1b56fb15',1,'src::CapaPresentacio::VistaRankingPartida']]],
  ['newtaulell_388',['newTaulell',['../classsrc_1_1_capa_presentacio_1_1_ctrl_presentacio.html#a9f86284cfad9d5ebd737bd0e86866c5b',1,'src::CapaPresentacio::CtrlPresentacio']]],
  ['nombrecasellesblanquesspecific_389',['nombreCasellesBlanquesSpecific',['../classsrc_1_1_capa_domini_1_1_classes_1_1_taulell.html#acde7321a22a15542949b9b89fba5b9d4',1,'src::CapaDomini::Classes::Taulell']]],
  ['nomnoukakuro_390',['nomnouKakuro',['../classsrc_1_1_capa_persistencia_1_1_ctrl_persistencia.html#a32456b1af53ce0de531425595771cb0e',1,'src::CapaPersistencia::CtrlPersistencia']]],
  ['nomnousoluciokakuro_391',['nomnouSolucioKakuro',['../classsrc_1_1_capa_persistencia_1_1_ctrl_persistencia.html#a4360d4e330a2419171912c6c7a0e9aee',1,'src::CapaPersistencia::CtrlPersistencia']]],
  ['nompartida_392',['nomPartida',['../classsrc_1_1_capa_persistencia_1_1_ctrl_persistencia.html#a31e473d10c73a431cd98e9bdeb04cde9',1,'src::CapaPersistencia::CtrlPersistencia']]],
  ['nomuser_393',['nomuser',['../classsrc_1_1_capa_presentacio_1_1_vista_ranking_global.html#a255bc84cff9caa2d60a82c3c3dc3deb0',1,'src.CapaPresentacio.VistaRankingGlobal.nomuser()'],['../classsrc_1_1_capa_presentacio_1_1_menu_principal.html#a8a47084a979c7f72e89afc9930a174be',1,'src.CapaPresentacio.MenuPrincipal.nomUser()'],['../classsrc_1_1_capa_presentacio_1_1_vista_ranking_global.html#a88357bf0f8ade8b78a77f5740d1b1ccd',1,'src.CapaPresentacio.VistaRankingGlobal.nomUser()']]],
  ['normalitzarespai_394',['NormalitzarEspai',['../classsrc_1_1_capa_domini_1_1_utils_1_1_final_variables.html#a10c05ca7f536cd6ae6a63c3874dd0def',1,'src::CapaDomini::Utils::FinalVariables']]],
  ['num_395',['num',['../classsrc_1_1_capa_domini_1_1_controladors_1_1_kakuro_solver_1_1_solucions.html#a4c9b58239904269dc942ebbc2df30e29',1,'src::CapaDomini::Controladors::KakuroSolver::Solucions']]],
  ['numcol_396',['numCol',['../classsrc_1_1_capa_presentacio_1_1_vista_partida.html#a8f92f0816ffc1f970100071961d4019d',1,'src::CapaPresentacio::VistaPartida']]],
  ['numfiles_397',['numFiles',['../classsrc_1_1_capa_presentacio_1_1_vista_partida.html#a727477f949bf5a597de40a446e8cefa5',1,'src::CapaPresentacio::VistaPartida']]],
  ['numsolucions_398',['numSolucions',['../classsrc_1_1_capa_domini_1_1_controladors_1_1_kakuro_solver.html#afd431f4b31818f2f453833c07de28ca2',1,'src.CapaDomini.Controladors.KakuroSolver.numSolucions()'],['../classsrc_1_1_capa_domini_1_1_controladors_1_1_kakuro_solver.html#a2d28d22a1ca17e79da73239b2931930f',1,'src.CapaDomini.Controladors.KakuroSolver.numSolucions()']]]
];
