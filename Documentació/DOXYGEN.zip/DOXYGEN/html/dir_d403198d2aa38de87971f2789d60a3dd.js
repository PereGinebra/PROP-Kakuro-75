var dir_d403198d2aa38de87971f2789d60a3dd =
[
    [ "CustomException.java", "_custom_exception_8java_source.html", null ],
    [ "ExceptionCasellaNoModificable.java", "_exception_casella_no_modificable_8java_source.html", null ],
    [ "ExceptionDificultatErronea.java", "_exception_dificultat_erronea_8java_source.html", null ],
    [ "ExceptionDimensionsTaulellErrones.java", "_exception_dimensions_taulell_errones_8java_source.html", null ],
    [ "ExceptionMidaIncorrecta.java", "_exception_mida_incorrecta_8java_source.html", null ],
    [ "ExceptionNoExisteixPartida.java", "_exception_no_existeix_partida_8java_source.html", null ],
    [ "ExceptionNoExisteixTaulell.java", "_exception_no_existeix_taulell_8java_source.html", null ],
    [ "ExceptionPosicioNoValida.java", "_exception_posicio_no_valida_8java_source.html", null ],
    [ "ExceptionStringBuidaInput.java", "_exception_string_buida_input_8java_source.html", null ],
    [ "ExceptionTaulellNoValid.java", "_exception_taulell_no_valid_8java_source.html", null ],
    [ "ExceptionTaulellSenseSolucio.java", "_exception_taulell_sense_solucio_8java_source.html", null ],
    [ "ExceptionValorForaRang.java", "_exception_valor_fora_rang_8java_source.html", null ],
    [ "ExceptionValorNoValid.java", "_exception_valor_no_valid_8java_source.html", null ],
    [ "ExeptionNoExisteixUsuari.java", "_exeption_no_existeix_usuari_8java_source.html", null ]
];