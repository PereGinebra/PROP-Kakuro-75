var namespacesrc_1_1_capa_domini_1_1_controladors =
[
    [ "ComparadorPerTempsDecreixent", "classsrc_1_1_capa_domini_1_1_controladors_1_1_comparador_per_temps_decreixent.html", "classsrc_1_1_capa_domini_1_1_controladors_1_1_comparador_per_temps_decreixent" ],
    [ "CtrlDomain", "classsrc_1_1_capa_domini_1_1_controladors_1_1_ctrl_domain.html", "classsrc_1_1_capa_domini_1_1_controladors_1_1_ctrl_domain" ],
    [ "CtrlPartida", "classsrc_1_1_capa_domini_1_1_controladors_1_1_ctrl_partida.html", "classsrc_1_1_capa_domini_1_1_controladors_1_1_ctrl_partida" ],
    [ "CtrlRankingGlobal", "classsrc_1_1_capa_domini_1_1_controladors_1_1_ctrl_ranking_global.html", "classsrc_1_1_capa_domini_1_1_controladors_1_1_ctrl_ranking_global" ],
    [ "CtrlUsuari", "classsrc_1_1_capa_domini_1_1_controladors_1_1_ctrl_usuari.html", "classsrc_1_1_capa_domini_1_1_controladors_1_1_ctrl_usuari" ],
    [ "KakuroSolver", "classsrc_1_1_capa_domini_1_1_controladors_1_1_kakuro_solver.html", "classsrc_1_1_capa_domini_1_1_controladors_1_1_kakuro_solver" ],
    [ "RandomKakuro", "classsrc_1_1_capa_domini_1_1_controladors_1_1_random_kakuro.html", "classsrc_1_1_capa_domini_1_1_controladors_1_1_random_kakuro" ]
];