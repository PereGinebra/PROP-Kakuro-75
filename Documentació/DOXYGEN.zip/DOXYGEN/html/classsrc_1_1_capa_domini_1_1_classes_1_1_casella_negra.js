var classsrc_1_1_capa_domini_1_1_classes_1_1_casella_negra =
[
    [ "CasellaNegra", "classsrc_1_1_capa_domini_1_1_classes_1_1_casella_negra.html#aecac3682b2d6507d49e5d30dba4cc3f0", null ],
    [ "esNegra", "classsrc_1_1_capa_domini_1_1_classes_1_1_casella_negra.html#ac2db05297da8e3ee5bdd96c80b23e811", null ],
    [ "setValor", "classsrc_1_1_capa_domini_1_1_classes_1_1_casella_negra.html#a41428e8c8fc178159b7efd235b407a26", null ]
];