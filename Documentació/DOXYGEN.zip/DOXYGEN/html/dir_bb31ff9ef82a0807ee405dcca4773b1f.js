var dir_bb31ff9ef82a0807ee405dcca4773b1f =
[
    [ "CtrlDomain.java", "_ctrl_domain_8java.html", [
      [ "CtrlDomain", "classsrc_1_1_capa_domini_1_1_controladors_1_1_ctrl_domain.html", "classsrc_1_1_capa_domini_1_1_controladors_1_1_ctrl_domain" ]
    ] ],
    [ "CtrlPartida.java", "_ctrl_partida_8java.html", [
      [ "CtrlPartida", "classsrc_1_1_capa_domini_1_1_controladors_1_1_ctrl_partida.html", "classsrc_1_1_capa_domini_1_1_controladors_1_1_ctrl_partida" ]
    ] ],
    [ "KakuroSolver.java", "_kakuro_solver_8java.html", [
      [ "KakuroSolver", "classsrc_1_1_capa_domini_1_1_controladors_1_1_kakuro_solver.html", "classsrc_1_1_capa_domini_1_1_controladors_1_1_kakuro_solver" ]
    ] ],
    [ "RandomKakuro.java", "_random_kakuro_8java.html", [
      [ "RandomKakuro", "classsrc_1_1_capa_domini_1_1_controladors_1_1_random_kakuro.html", "classsrc_1_1_capa_domini_1_1_controladors_1_1_random_kakuro" ]
    ] ]
];