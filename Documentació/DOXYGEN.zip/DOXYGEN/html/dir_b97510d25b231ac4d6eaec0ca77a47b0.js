var dir_b97510d25b231ac4d6eaec0ca77a47b0 =
[
    [ "DriverCasella.java", "_driver_casella_8java_source.html", null ],
    [ "DriverKakuroSolver.java", "_driver_kakuro_solver_8java_source.html", null ],
    [ "DriverPartida.java", "_driver_partida_8java_source.html", null ],
    [ "DriverTaulell.java", "_driver_taulell_8java_source.html", null ]
];