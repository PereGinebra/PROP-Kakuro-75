var dir_3fe6c40884e616cbf6e91b44273def32 =
[
    [ "CtrlDomain.java", "_ctrl_domain_8java.html", [
      [ "CtrlDomain", "classsrc_1_1_capa_domini_1_1_controladors_1_1_ctrl_domain.html", "classsrc_1_1_capa_domini_1_1_controladors_1_1_ctrl_domain" ]
    ] ],
    [ "CtrlPartida.java", "_ctrl_partida_8java.html", [
      [ "CtrlPartida", "classsrc_1_1_capa_domini_1_1_controladors_1_1_ctrl_partida.html", "classsrc_1_1_capa_domini_1_1_controladors_1_1_ctrl_partida" ]
    ] ],
    [ "CtrlRankingGlobal.java", "_ctrl_ranking_global_8java.html", [
      [ "CtrlRankingGlobal", "classsrc_1_1_capa_domini_1_1_controladors_1_1_ctrl_ranking_global.html", "classsrc_1_1_capa_domini_1_1_controladors_1_1_ctrl_ranking_global" ],
      [ "ComparadorPerTempsDecreixent", "classsrc_1_1_capa_domini_1_1_controladors_1_1_comparador_per_temps_decreixent.html", "classsrc_1_1_capa_domini_1_1_controladors_1_1_comparador_per_temps_decreixent" ]
    ] ],
    [ "CtrlUsuari.java", "_ctrl_usuari_8java.html", [
      [ "CtrlUsuari", "classsrc_1_1_capa_domini_1_1_controladors_1_1_ctrl_usuari.html", "classsrc_1_1_capa_domini_1_1_controladors_1_1_ctrl_usuari" ]
    ] ],
    [ "KakuroSolver.java", "_kakuro_solver_8java.html", [
      [ "KakuroSolver", "classsrc_1_1_capa_domini_1_1_controladors_1_1_kakuro_solver.html", "classsrc_1_1_capa_domini_1_1_controladors_1_1_kakuro_solver" ],
      [ "Solucions", "classsrc_1_1_capa_domini_1_1_controladors_1_1_kakuro_solver_1_1_solucions.html", "classsrc_1_1_capa_domini_1_1_controladors_1_1_kakuro_solver_1_1_solucions" ]
    ] ],
    [ "RandomKakuro.java", "_random_kakuro_8java.html", [
      [ "RandomKakuro", "classsrc_1_1_capa_domini_1_1_controladors_1_1_random_kakuro.html", "classsrc_1_1_capa_domini_1_1_controladors_1_1_random_kakuro" ]
    ] ]
];