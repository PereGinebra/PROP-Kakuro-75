var classsrc_1_1_capa_domini_1_1_controladors_1_1_comparador_per_temps_decreixent =
[
    [ "compare", "classsrc_1_1_capa_domini_1_1_controladors_1_1_comparador_per_temps_decreixent.html#ad20ec982e0d16d46f155b5fbfa030cac", null ],
    [ "CompEntry", "classsrc_1_1_capa_domini_1_1_controladors_1_1_comparador_per_temps_decreixent.html#aff9fa868b29ccb1fe3ee899c5f1bd8f8", null ]
];