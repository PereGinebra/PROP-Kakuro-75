var namespacesrc_1_1_capa_presentacio =
[
    [ "CtrlPresentacio", "classsrc_1_1_capa_presentacio_1_1_ctrl_presentacio.html", "classsrc_1_1_capa_presentacio_1_1_ctrl_presentacio" ],
    [ "LengthRestrictedDocument", "classsrc_1_1_capa_presentacio_1_1_length_restricted_document.html", "classsrc_1_1_capa_presentacio_1_1_length_restricted_document" ],
    [ "MenuPrincipal", "classsrc_1_1_capa_presentacio_1_1_menu_principal.html", "classsrc_1_1_capa_presentacio_1_1_menu_principal" ],
    [ "move", "classsrc_1_1_capa_presentacio_1_1move.html", "classsrc_1_1_capa_presentacio_1_1move" ],
    [ "PantallaPrincipal", "classsrc_1_1_capa_presentacio_1_1_pantalla_principal.html", "classsrc_1_1_capa_presentacio_1_1_pantalla_principal" ],
    [ "SignUp", "classsrc_1_1_capa_presentacio_1_1_sign_up.html", "classsrc_1_1_capa_presentacio_1_1_sign_up" ],
    [ "VistaAutogenerar", "classsrc_1_1_capa_presentacio_1_1_vista_autogenerar.html", "classsrc_1_1_capa_presentacio_1_1_vista_autogenerar" ],
    [ "VistaCrearManualment", "classsrc_1_1_capa_presentacio_1_1_vista_crear_manualment.html", "classsrc_1_1_capa_presentacio_1_1_vista_crear_manualment" ],
    [ "VistaNewGame", "classsrc_1_1_capa_presentacio_1_1_vista_new_game.html", "classsrc_1_1_capa_presentacio_1_1_vista_new_game" ],
    [ "VistaPartida", "classsrc_1_1_capa_presentacio_1_1_vista_partida.html", "classsrc_1_1_capa_presentacio_1_1_vista_partida" ],
    [ "VistaRankingGlobal", "classsrc_1_1_capa_presentacio_1_1_vista_ranking_global.html", "classsrc_1_1_capa_presentacio_1_1_vista_ranking_global" ],
    [ "VistaRankingPartida", "classsrc_1_1_capa_presentacio_1_1_vista_ranking_partida.html", "classsrc_1_1_capa_presentacio_1_1_vista_ranking_partida" ],
    [ "VistaSeleccioKakuro", "classsrc_1_1_capa_presentacio_1_1_vista_seleccio_kakuro.html", "classsrc_1_1_capa_presentacio_1_1_vista_seleccio_kakuro" ]
];