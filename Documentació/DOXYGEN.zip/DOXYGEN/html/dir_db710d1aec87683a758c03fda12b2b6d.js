var dir_db710d1aec87683a758c03fda12b2b6d =
[
    [ "Casella.java", "_casella_8java.html", [
      [ "Casella", "classsrc_1_1_capa_domini_1_1_classes_1_1_casella.html", "classsrc_1_1_capa_domini_1_1_classes_1_1_casella" ]
    ] ],
    [ "CasellaBlanca.java", "_casella_blanca_8java.html", [
      [ "CasellaBlanca", "classsrc_1_1_capa_domini_1_1_classes_1_1_casella_blanca.html", "classsrc_1_1_capa_domini_1_1_classes_1_1_casella_blanca" ]
    ] ],
    [ "CasellaNegra.java", "_casella_negra_8java.html", [
      [ "CasellaNegra", "classsrc_1_1_capa_domini_1_1_classes_1_1_casella_negra.html", "classsrc_1_1_capa_domini_1_1_classes_1_1_casella_negra" ]
    ] ],
    [ "CasellaSuma.java", "_casella_suma_8java.html", [
      [ "CasellaSuma", "classsrc_1_1_capa_domini_1_1_classes_1_1_casella_suma.html", "classsrc_1_1_capa_domini_1_1_classes_1_1_casella_suma" ]
    ] ],
    [ "Partida.java", "_partida_8java.html", [
      [ "Partida", "classsrc_1_1_capa_domini_1_1_classes_1_1_partida.html", "classsrc_1_1_capa_domini_1_1_classes_1_1_partida" ]
    ] ],
    [ "RankingGlobal.java", "_ranking_global_8java.html", [
      [ "RankingGlobal", "classsrc_1_1_capa_domini_1_1_classes_1_1_ranking_global.html", "classsrc_1_1_capa_domini_1_1_classes_1_1_ranking_global" ]
    ] ],
    [ "RankingTaulell.java", "_ranking_taulell_8java.html", [
      [ "RankingTaulell", "classsrc_1_1_capa_domini_1_1_classes_1_1_ranking_taulell.html", "classsrc_1_1_capa_domini_1_1_classes_1_1_ranking_taulell" ],
      [ "CompEntryByTime", "classsrc_1_1_capa_domini_1_1_classes_1_1_comp_entry_by_time.html", "classsrc_1_1_capa_domini_1_1_classes_1_1_comp_entry_by_time" ],
      [ "CompEntryByName", "classsrc_1_1_capa_domini_1_1_classes_1_1_comp_entry_by_name.html", "classsrc_1_1_capa_domini_1_1_classes_1_1_comp_entry_by_name" ]
    ] ],
    [ "Taulell.java", "_taulell_8java.html", [
      [ "Taulell", "classsrc_1_1_capa_domini_1_1_classes_1_1_taulell.html", "classsrc_1_1_capa_domini_1_1_classes_1_1_taulell" ]
    ] ],
    [ "Usuari.java", "_usuari_8java.html", [
      [ "Usuari", "classsrc_1_1_capa_domini_1_1_classes_1_1_usuari.html", "classsrc_1_1_capa_domini_1_1_classes_1_1_usuari" ]
    ] ]
];