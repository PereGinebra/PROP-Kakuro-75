var classsrc_1_1_exceptions_1_1_exception_no_existeix_taulell =
[
    [ "getMessage", "classsrc_1_1_exceptions_1_1_exception_no_existeix_taulell.html#a9976c7a8e858de62b8967b4f7cf7f0e5", null ]
];