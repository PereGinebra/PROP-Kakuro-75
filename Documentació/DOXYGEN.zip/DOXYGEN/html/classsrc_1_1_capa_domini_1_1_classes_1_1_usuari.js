var classsrc_1_1_capa_domini_1_1_classes_1_1_usuari =
[
    [ "Usuari", "classsrc_1_1_capa_domini_1_1_classes_1_1_usuari.html#a86fdabe5b645df5149e158955fd97387", null ],
    [ "Usuari", "classsrc_1_1_capa_domini_1_1_classes_1_1_usuari.html#ad8e33ef19a4b5009709f0be63442b19d", null ],
    [ "getPassword", "classsrc_1_1_capa_domini_1_1_classes_1_1_usuari.html#a0cae9756c5c646c0e509ed57e31a0b5e", null ],
    [ "getUser", "classsrc_1_1_capa_domini_1_1_classes_1_1_usuari.html#a84da36f5eb180c7b496bc165b8b4b0db", null ],
    [ "password", "classsrc_1_1_capa_domini_1_1_classes_1_1_usuari.html#accae175951b73add28cddbbfc9259271", null ],
    [ "user", "classsrc_1_1_capa_domini_1_1_classes_1_1_usuari.html#a8a0c462f35ee87887dc419892eb29478", null ]
];