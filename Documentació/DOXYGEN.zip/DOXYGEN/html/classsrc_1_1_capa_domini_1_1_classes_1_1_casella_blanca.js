var classsrc_1_1_capa_domini_1_1_classes_1_1_casella_blanca =
[
    [ "CasellaBlanca", "classsrc_1_1_capa_domini_1_1_classes_1_1_casella_blanca.html#afd818c328add807944ab2c018175e530", null ],
    [ "CasellaBlanca", "classsrc_1_1_capa_domini_1_1_classes_1_1_casella_blanca.html#ae860ed601d85c4ab8e53e97e45db0e8c", null ],
    [ "esBlanca", "classsrc_1_1_capa_domini_1_1_classes_1_1_casella_blanca.html#a55b5594bbd13a8efdbae9a1d0f22e88d", null ],
    [ "setValor", "classsrc_1_1_capa_domini_1_1_classes_1_1_casella_blanca.html#a345e24373dbd573d6b4d08aa9e63af38", null ]
];