var classsrc_1_1_capa_domini_1_1_classes_1_1_comp_entry_by_time =
[
    [ "compare", "classsrc_1_1_capa_domini_1_1_classes_1_1_comp_entry_by_time.html#aacf2670c7e7cd4d5e033932f81c94882", null ],
    [ "CompEntry", "classsrc_1_1_capa_domini_1_1_classes_1_1_comp_entry_by_time.html#a729df4f85abb39a77f7b02966cdc3623", null ]
];