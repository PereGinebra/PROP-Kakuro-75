var classsrc_1_1_capa_domini_1_1_utils_1_1_permutacions =
[
    [ "Permutacions", "classsrc_1_1_capa_domini_1_1_utils_1_1_permutacions.html#afebfdeb6ee47e07c3819653998c84e1f", null ],
    [ "interseccio", "classsrc_1_1_capa_domini_1_1_utils_1_1_permutacions.html#a2965814416f43f9a82011bf698b6bc79", null ],
    [ "midaInterseccio", "classsrc_1_1_capa_domini_1_1_utils_1_1_permutacions.html#a0e0dd3d3cb0e743b831ea31158f407bb", null ],
    [ "omplirValors", "classsrc_1_1_capa_domini_1_1_utils_1_1_permutacions.html#a29e171eb4e1f272c3cdf76e7840809e8", null ],
    [ "pertany", "classsrc_1_1_capa_domini_1_1_utils_1_1_permutacions.html#af9dd314003d39a597e97211544094052", null ],
    [ "valorsPossiblesDeUnaCasella", "classsrc_1_1_capa_domini_1_1_utils_1_1_permutacions.html#a1475afedc2b36a437ffaafb746f11ca3", null ],
    [ "valorsPossibles", "classsrc_1_1_capa_domini_1_1_utils_1_1_permutacions.html#a770c40429e442173ace25cae76c5ebee", null ]
];