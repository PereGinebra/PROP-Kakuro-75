var classsrc_1_1_capa_domini_1_1_classes_1_1_casella_suma =
[
    [ "CasellaSuma", "classsrc_1_1_capa_domini_1_1_classes_1_1_casella_suma.html#aa37a92c3a45fa564f0517d98490dd081", null ],
    [ "CasellaSuma", "classsrc_1_1_capa_domini_1_1_classes_1_1_casella_suma.html#a063c27aa0dd238b35c1f5f6ddefaa54d", null ],
    [ "esSuma", "classsrc_1_1_capa_domini_1_1_classes_1_1_casella_suma.html#a456f15cf8d81902f2fa0bed1cf8ea2f4", null ],
    [ "getSumaColumna", "classsrc_1_1_capa_domini_1_1_classes_1_1_casella_suma.html#a80f9590075b9655b404ca6c6d42190dc", null ],
    [ "getSumaFila", "classsrc_1_1_capa_domini_1_1_classes_1_1_casella_suma.html#a0f5225e001364fbd803425362d1df763", null ],
    [ "setValor", "classsrc_1_1_capa_domini_1_1_classes_1_1_casella_suma.html#a2f41325a19944b2fcd63f8b9053b4e19", null ],
    [ "setValorsSuma", "classsrc_1_1_capa_domini_1_1_classes_1_1_casella_suma.html#ad5239a86de2694655824f9a038b22349", null ],
    [ "sumaCol", "classsrc_1_1_capa_domini_1_1_classes_1_1_casella_suma.html#a90d3dc10ed8f1fb5a5bdf5ecb7cef2bd", null ],
    [ "sumaFila", "classsrc_1_1_capa_domini_1_1_classes_1_1_casella_suma.html#a1c71f268fc8af46dc7b4722b8476deee", null ]
];