var classsrc_1_1_capa_domini_1_1_classes_1_1_usuario =
[
    [ "AddPartida", "classsrc_1_1_capa_domini_1_1_classes_1_1_usuario.html#a0b83eccf2fa0314db33dce191c4517ba", null ],
    [ "getPassword", "classsrc_1_1_capa_domini_1_1_classes_1_1_usuario.html#ad6eb79697c29f9e89b7f2f17a3a8cf23", null ],
    [ "getUsername", "classsrc_1_1_capa_domini_1_1_classes_1_1_usuario.html#ac471c4b369628756cbb937632e20435a", null ],
    [ "setPartidasEnCurso", "classsrc_1_1_capa_domini_1_1_classes_1_1_usuario.html#ab4d935d54f30c32e1c955a8bf2c6eee3", null ],
    [ "setPartidasJugadas", "classsrc_1_1_capa_domini_1_1_classes_1_1_usuario.html#aaaa96337b796de05933fa3122aea3007", null ],
    [ "setPassword", "classsrc_1_1_capa_domini_1_1_classes_1_1_usuario.html#a3026f1d5aeaa2c6a888cc712eb5266a4", null ],
    [ "setUsername", "classsrc_1_1_capa_domini_1_1_classes_1_1_usuario.html#adc327dddd38122c61e4b0dd0f22f555a", null ]
];