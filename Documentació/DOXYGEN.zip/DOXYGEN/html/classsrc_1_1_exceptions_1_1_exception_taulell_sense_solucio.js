var classsrc_1_1_exceptions_1_1_exception_taulell_sense_solucio =
[
    [ "getMessage", "classsrc_1_1_exceptions_1_1_exception_taulell_sense_solucio.html#a5795d1618fe567124deda592a25dea53", null ]
];