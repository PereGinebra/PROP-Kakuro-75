var namespacesrc_1_1_exceptions =
[
    [ "CustomException", "classsrc_1_1_exceptions_1_1_custom_exception.html", "classsrc_1_1_exceptions_1_1_custom_exception" ],
    [ "ExceptionCasellaNoModificable", "classsrc_1_1_exceptions_1_1_exception_casella_no_modificable.html", "classsrc_1_1_exceptions_1_1_exception_casella_no_modificable" ],
    [ "ExceptionDificultatErronea", "classsrc_1_1_exceptions_1_1_exception_dificultat_erronea.html", "classsrc_1_1_exceptions_1_1_exception_dificultat_erronea" ],
    [ "ExceptionDimensionsTaulellErrones", "classsrc_1_1_exceptions_1_1_exception_dimensions_taulell_errones.html", "classsrc_1_1_exceptions_1_1_exception_dimensions_taulell_errones" ],
    [ "ExceptionMidaIncorrecta", "classsrc_1_1_exceptions_1_1_exception_mida_incorrecta.html", "classsrc_1_1_exceptions_1_1_exception_mida_incorrecta" ],
    [ "ExceptionNoExisteixPartida", "classsrc_1_1_exceptions_1_1_exception_no_existeix_partida.html", "classsrc_1_1_exceptions_1_1_exception_no_existeix_partida" ],
    [ "ExceptionNoExisteixTaulell", "classsrc_1_1_exceptions_1_1_exception_no_existeix_taulell.html", "classsrc_1_1_exceptions_1_1_exception_no_existeix_taulell" ],
    [ "ExceptionPosicioNoValida", "classsrc_1_1_exceptions_1_1_exception_posicio_no_valida.html", "classsrc_1_1_exceptions_1_1_exception_posicio_no_valida" ],
    [ "ExceptionStringBuidaInput", "classsrc_1_1_exceptions_1_1_exception_string_buida_input.html", "classsrc_1_1_exceptions_1_1_exception_string_buida_input" ],
    [ "ExceptionTaulellNoValid", "classsrc_1_1_exceptions_1_1_exception_taulell_no_valid.html", "classsrc_1_1_exceptions_1_1_exception_taulell_no_valid" ],
    [ "ExceptionTaulellSenseSolucio", "classsrc_1_1_exceptions_1_1_exception_taulell_sense_solucio.html", "classsrc_1_1_exceptions_1_1_exception_taulell_sense_solucio" ],
    [ "ExceptionValorForaRang", "classsrc_1_1_exceptions_1_1_exception_valor_fora_rang.html", "classsrc_1_1_exceptions_1_1_exception_valor_fora_rang" ],
    [ "ExceptionValorNoValid", "classsrc_1_1_exceptions_1_1_exception_valor_no_valid.html", "classsrc_1_1_exceptions_1_1_exception_valor_no_valid" ],
    [ "ExeptionNoExisteixUsuari", "classsrc_1_1_exceptions_1_1_exeption_no_existeix_usuari.html", "classsrc_1_1_exceptions_1_1_exeption_no_existeix_usuari" ]
];