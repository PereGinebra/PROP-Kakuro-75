var classsrc_1_1_capa_domini_1_1_classes_1_1_casella =
[
    [ "Casella", "classsrc_1_1_capa_domini_1_1_classes_1_1_casella.html#a6c28807e7a8b4dff0acb92a0cecb98cf", null ],
    [ "Casella", "classsrc_1_1_capa_domini_1_1_classes_1_1_casella.html#a44d50a11c32653520b55764cf22bdfbc", null ],
    [ "esBlanca", "classsrc_1_1_capa_domini_1_1_classes_1_1_casella.html#afe7387f62ebfa805a9ac68cf1631b9c1", null ],
    [ "esNegra", "classsrc_1_1_capa_domini_1_1_classes_1_1_casella.html#a4b302f507195ca66274db6eacf20a9ef", null ],
    [ "esSuma", "classsrc_1_1_capa_domini_1_1_classes_1_1_casella.html#a489d5e9852fc3d464dacf486c1f54a8a", null ],
    [ "getSumaColumna", "classsrc_1_1_capa_domini_1_1_classes_1_1_casella.html#a935cc9468573c2d471ee72b072a9ab90", null ],
    [ "getSumaFila", "classsrc_1_1_capa_domini_1_1_classes_1_1_casella.html#ac2805a8492b427055c6a74ea9257df81", null ],
    [ "getValor", "classsrc_1_1_capa_domini_1_1_classes_1_1_casella.html#a292171032d2d3b59389b8801f9f92ebc", null ],
    [ "setValor", "classsrc_1_1_capa_domini_1_1_classes_1_1_casella.html#a89bf6ceee263d8f2e69d3f1f263a6c99", null ],
    [ "valor", "classsrc_1_1_capa_domini_1_1_classes_1_1_casella.html#a52f218332e6f73f0eef3447e7b5cef85", null ]
];