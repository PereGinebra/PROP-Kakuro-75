var dir_ce65bc23bcc0f924770b8419a8b661d5 =
[
    [ "CtrlPresentacio.java", "_ctrl_presentacio_8java.html", [
      [ "CtrlPresentacio", "classsrc_1_1_capa_presentacio_1_1_ctrl_presentacio.html", "classsrc_1_1_capa_presentacio_1_1_ctrl_presentacio" ]
    ] ],
    [ "MenuPrincipal.java", "_menu_principal_8java.html", [
      [ "MenuPrincipal", "classsrc_1_1_capa_presentacio_1_1_menu_principal.html", "classsrc_1_1_capa_presentacio_1_1_menu_principal" ]
    ] ],
    [ "PantallaPrincipal.java", "_pantalla_principal_8java.html", [
      [ "PantallaPrincipal", "classsrc_1_1_capa_presentacio_1_1_pantalla_principal.html", "classsrc_1_1_capa_presentacio_1_1_pantalla_principal" ]
    ] ],
    [ "SignUp.java", "_sign_up_8java.html", [
      [ "SignUp", "classsrc_1_1_capa_presentacio_1_1_sign_up.html", "classsrc_1_1_capa_presentacio_1_1_sign_up" ]
    ] ],
    [ "VistaAutogenerar.java", "_vista_autogenerar_8java.html", [
      [ "VistaAutogenerar", "classsrc_1_1_capa_presentacio_1_1_vista_autogenerar.html", "classsrc_1_1_capa_presentacio_1_1_vista_autogenerar" ]
    ] ],
    [ "VistaCrearManualment.java", "_vista_crear_manualment_8java.html", [
      [ "VistaCrearManualment", "classsrc_1_1_capa_presentacio_1_1_vista_crear_manualment.html", "classsrc_1_1_capa_presentacio_1_1_vista_crear_manualment" ]
    ] ],
    [ "VistaNewGame.java", "_vista_new_game_8java.html", [
      [ "VistaNewGame", "classsrc_1_1_capa_presentacio_1_1_vista_new_game.html", "classsrc_1_1_capa_presentacio_1_1_vista_new_game" ]
    ] ],
    [ "VistaPartida.java", "_vista_partida_8java.html", [
      [ "VistaPartida", "classsrc_1_1_capa_presentacio_1_1_vista_partida.html", "classsrc_1_1_capa_presentacio_1_1_vista_partida" ],
      [ "move", "classsrc_1_1_capa_presentacio_1_1move.html", "classsrc_1_1_capa_presentacio_1_1move" ],
      [ "LengthRestrictedDocument", "classsrc_1_1_capa_presentacio_1_1_length_restricted_document.html", "classsrc_1_1_capa_presentacio_1_1_length_restricted_document" ]
    ] ],
    [ "VistaRankingGlobal.java", "_vista_ranking_global_8java.html", [
      [ "VistaRankingGlobal", "classsrc_1_1_capa_presentacio_1_1_vista_ranking_global.html", "classsrc_1_1_capa_presentacio_1_1_vista_ranking_global" ]
    ] ],
    [ "VistaRankingPartida.java", "_vista_ranking_partida_8java.html", [
      [ "VistaRankingPartida", "classsrc_1_1_capa_presentacio_1_1_vista_ranking_partida.html", "classsrc_1_1_capa_presentacio_1_1_vista_ranking_partida" ]
    ] ],
    [ "VistaSeleccioKakuro.java", "_vista_seleccio_kakuro_8java.html", [
      [ "VistaSeleccioKakuro", "classsrc_1_1_capa_presentacio_1_1_vista_seleccio_kakuro.html", "classsrc_1_1_capa_presentacio_1_1_vista_seleccio_kakuro" ]
    ] ]
];