var classsrc_1_1_exceptions_1_1_exception_posicio_no_valida =
[
    [ "getMessage", "classsrc_1_1_exceptions_1_1_exception_posicio_no_valida.html#a2ee5b10ee1a5e61664dc1fb733ec002d", null ]
];