var dir_6c6bd17664e4f5fe5a8944fc489e7b85 =
[
    [ "DriverCasella.java", "_driver_casella_8java.html", [
      [ "DriverCasella", "classsrc_1_1_capa_domini_1_1_drivers_1_1_driver_casella.html", "classsrc_1_1_capa_domini_1_1_drivers_1_1_driver_casella" ]
    ] ],
    [ "DriverCtrlDomain.java", "_driver_ctrl_domain_8java.html", [
      [ "DriverCtrlDomain", "classsrc_1_1_capa_domini_1_1_drivers_1_1_driver_ctrl_domain.html", "classsrc_1_1_capa_domini_1_1_drivers_1_1_driver_ctrl_domain" ]
    ] ],
    [ "DriverKakuroSolver.java", "_driver_kakuro_solver_8java.html", [
      [ "DriverKakuroSolver", "classsrc_1_1_capa_domini_1_1_drivers_1_1_driver_kakuro_solver.html", "classsrc_1_1_capa_domini_1_1_drivers_1_1_driver_kakuro_solver" ]
    ] ],
    [ "DriverPartida.java", "_driver_partida_8java.html", [
      [ "DriverPartida", "classsrc_1_1_capa_domini_1_1_drivers_1_1_driver_partida.html", "classsrc_1_1_capa_domini_1_1_drivers_1_1_driver_partida" ]
    ] ],
    [ "DriverTaulell.java", "_driver_taulell_8java.html", [
      [ "DriverTaulell", "classsrc_1_1_capa_domini_1_1_drivers_1_1_driver_taulell.html", "classsrc_1_1_capa_domini_1_1_drivers_1_1_driver_taulell" ]
    ] ]
];