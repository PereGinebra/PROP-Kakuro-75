var classsrc_1_1_capa_presentacio_1_1_vista_new_game =
[
    [ "VistaNewGame", "classsrc_1_1_capa_presentacio_1_1_vista_new_game.html#a78f140e621f9fbe01225a5e5638d0325", null ],
    [ "botoautogenerarActionPerformed", "classsrc_1_1_capa_presentacio_1_1_vista_new_game.html#a297049da95a6c80446c601789590d36f", null ],
    [ "botocarregarActionPerformed", "classsrc_1_1_capa_presentacio_1_1_vista_new_game.html#ab0fc5ab3ceeb02cdbb6e1857360797f2", null ],
    [ "botomanualActionPerformed", "classsrc_1_1_capa_presentacio_1_1_vista_new_game.html#aaaae34c06586f91d19065a2968776e71", null ],
    [ "botoreturnActionPerformed", "classsrc_1_1_capa_presentacio_1_1_vista_new_game.html#a123dd6f741a58f6d69c2cdd747366d3d", null ],
    [ "initComponents", "classsrc_1_1_capa_presentacio_1_1_vista_new_game.html#a46df5422793cc28be883a7a9d278dc18", null ],
    [ "botoautogenerar", "classsrc_1_1_capa_presentacio_1_1_vista_new_game.html#a34788c3230ea8225a25b8e20e3968955", null ],
    [ "botocarregar", "classsrc_1_1_capa_presentacio_1_1_vista_new_game.html#ad796d9593875a27c4993628b4502d369", null ],
    [ "botomanual", "classsrc_1_1_capa_presentacio_1_1_vista_new_game.html#ac30fa2513abd25eb8c58eff43cc87f82", null ],
    [ "botoreturn", "classsrc_1_1_capa_presentacio_1_1_vista_new_game.html#a4f9382dbc465070570cf14c3c639b86b", null ],
    [ "cp", "classsrc_1_1_capa_presentacio_1_1_vista_new_game.html#a0ecd1a082d683ab2a79fd1b620fe87a3", null ],
    [ "jLabel1", "classsrc_1_1_capa_presentacio_1_1_vista_new_game.html#a3bac736c8c4a3996dc3f9e5cbf8da8f0", null ],
    [ "jPanel1", "classsrc_1_1_capa_presentacio_1_1_vista_new_game.html#ab907b6b2df56661a1fc65976caefa8de", null ],
    [ "parent", "classsrc_1_1_capa_presentacio_1_1_vista_new_game.html#af3330a4f0d0874823a0c2b6ed83a7480", null ]
];