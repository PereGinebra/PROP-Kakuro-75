var classsrc_1_1_capa_domini_1_1_controladors_1_1_kakuro_solver =
[
    [ "Solucions", "classsrc_1_1_capa_domini_1_1_controladors_1_1_kakuro_solver_1_1_solucions.html", "classsrc_1_1_capa_domini_1_1_controladors_1_1_kakuro_solver_1_1_solucions" ],
    [ "KakuroSolver", "classsrc_1_1_capa_domini_1_1_controladors_1_1_kakuro_solver.html#aafb36cb8f9ba469e4a84e8480b3a0e27", null ],
    [ "KakuroSolver", "classsrc_1_1_capa_domini_1_1_controladors_1_1_kakuro_solver.html#a1b542ca0475507952e40d459a36c3d7f", null ],
    [ "numSolucions", "classsrc_1_1_capa_domini_1_1_controladors_1_1_kakuro_solver.html#a2d28d22a1ca17e79da73239b2931930f", null ],
    [ "setTaulellSolucio", "classsrc_1_1_capa_domini_1_1_controladors_1_1_kakuro_solver.html#a7d6164f4b18f834df42df3a89bd27449", null ],
    [ "solucio", "classsrc_1_1_capa_domini_1_1_controladors_1_1_kakuro_solver.html#ad169985b9b4cfb694ff46266317f9688", null ],
    [ "solver", "classsrc_1_1_capa_domini_1_1_controladors_1_1_kakuro_solver.html#a793d1d9e7901c4045d2ee8502e3d6798", null ],
    [ "sumaHoritzontalIncorrecte", "classsrc_1_1_capa_domini_1_1_controladors_1_1_kakuro_solver.html#a5fe6f11c85bc3311fa66554ced24f333", null ],
    [ "sumaVerticalIncorrecte", "classsrc_1_1_capa_domini_1_1_controladors_1_1_kakuro_solver.html#a5d39a284bf9974831a62eb836a0bd0bc", null ],
    [ "valorPossible", "classsrc_1_1_capa_domini_1_1_controladors_1_1_kakuro_solver.html#a0d954e796dc36834d32b4251d497737f", null ],
    [ "columnes", "classsrc_1_1_capa_domini_1_1_controladors_1_1_kakuro_solver.html#ab3e998fb76e2e75b2b03fc340fa993d8", null ],
    [ "files", "classsrc_1_1_capa_domini_1_1_controladors_1_1_kakuro_solver.html#a5083cf7bfdcf96435cdd111e70829310", null ],
    [ "numSolucions", "classsrc_1_1_capa_domini_1_1_controladors_1_1_kakuro_solver.html#afd431f4b31818f2f453833c07de28ca2", null ],
    [ "taulell", "classsrc_1_1_capa_domini_1_1_controladors_1_1_kakuro_solver.html#a71d5afb9fa33a69eb2c2e2714e1714ac", null ]
];