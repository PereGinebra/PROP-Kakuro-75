var classsrc_1_1_capa_domini_1_1_classes_1_1_ranking_global =
[
    [ "RankingGlobal", "classsrc_1_1_capa_domini_1_1_classes_1_1_ranking_global.html#abe8b83c523373c905b101cbd39012520", null ],
    [ "afegirNouUsuari", "classsrc_1_1_capa_domini_1_1_classes_1_1_ranking_global.html#a70a8cf93c2118039b40a562cd968f66b", null ],
    [ "getIndexPerUsuariExistent", "classsrc_1_1_capa_domini_1_1_classes_1_1_ranking_global.html#ab62a50015541ba9a7ae2eb3c323e4413", null ],
    [ "getIndexPerUsuariNou", "classsrc_1_1_capa_domini_1_1_classes_1_1_ranking_global.html#a3be196d94767fd6df9f60c7507b68821", null ],
    [ "getMida", "classsrc_1_1_capa_domini_1_1_classes_1_1_ranking_global.html#afce910a7bcdc8be9947c6ec069fb59d0", null ],
    [ "getPosUsuariExistent", "classsrc_1_1_capa_domini_1_1_classes_1_1_ranking_global.html#ac44469c43aaacfc7d0d11b1a0c777a02", null ],
    [ "getPosUsuariNou", "classsrc_1_1_capa_domini_1_1_classes_1_1_ranking_global.html#a8739e5744102ad58e9f754267f11c0c4", null ],
    [ "getPuntuacioTotalUsuariPerNom", "classsrc_1_1_capa_domini_1_1_classes_1_1_ranking_global.html#a3acfb191031afe76ea7353864c3902bf", null ],
    [ "getPuntuacioUsuariOrdreAlfabetic", "classsrc_1_1_capa_domini_1_1_classes_1_1_ranking_global.html#a0ba2bd52824ad4de11259da8996b14d5", null ],
    [ "getRankingPerOrdreAlfabetic", "classsrc_1_1_capa_domini_1_1_classes_1_1_ranking_global.html#ac8f8e8a4a6f4937419933415155139db", null ],
    [ "sumarPuntuacioAUsuari", "classsrc_1_1_capa_domini_1_1_classes_1_1_ranking_global.html#a913e3bbc13267d6cf58b1bc039f60cc0", null ],
    [ "treureUsuari", "classsrc_1_1_capa_domini_1_1_classes_1_1_ranking_global.html#ad0aef228f332db6457039d74bf3e4ce9", null ],
    [ "ranking", "classsrc_1_1_capa_domini_1_1_classes_1_1_ranking_global.html#af1ffdf0e578b2e7184d4ee5946cdffb9", null ]
];