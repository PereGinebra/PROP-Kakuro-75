var classsrc_1_1_capa_domini_1_1_classes_1_1_ranking_taulell =
[
    [ "RankingTaulell", "classsrc_1_1_capa_domini_1_1_classes_1_1_ranking_taulell.html#a7f5e51eed4ec253996c66c55337a9618", null ],
    [ "RankingTaulell", "classsrc_1_1_capa_domini_1_1_classes_1_1_ranking_taulell.html#a5c87914af8a69d2721b3cd20ab578268", null ],
    [ "getRankingNom", "classsrc_1_1_capa_domini_1_1_classes_1_1_ranking_taulell.html#ac386f91f6c9770d2579dda5f1ca5f77c", null ],
    [ "getRankingTemps", "classsrc_1_1_capa_domini_1_1_classes_1_1_ranking_taulell.html#af0077771fa566ce4d8968a8c5694b0d1", null ],
    [ "insertEntry", "classsrc_1_1_capa_domini_1_1_classes_1_1_ranking_taulell.html#a7ceeebfb58302f69709efa532851b4fb", null ],
    [ "recInsert", "classsrc_1_1_capa_domini_1_1_classes_1_1_ranking_taulell.html#af4ab82a8abbbd4e2ba34de47276b8052", null ],
    [ "sortRankingByTime", "classsrc_1_1_capa_domini_1_1_classes_1_1_ranking_taulell.html#aec519e21a15be0a8f710236c459ad481", null ],
    [ "rank", "classsrc_1_1_capa_domini_1_1_classes_1_1_ranking_taulell.html#aa93c9bdfed8c9e270f798117c6d6f3b7", null ]
];