var classsrc_1_1_exceptions_1_1_exception_no_existeix_partida =
[
    [ "getMessage", "classsrc_1_1_exceptions_1_1_exception_no_existeix_partida.html#a4f8a338ce769e86ca8cf82c47899e57f", null ]
];