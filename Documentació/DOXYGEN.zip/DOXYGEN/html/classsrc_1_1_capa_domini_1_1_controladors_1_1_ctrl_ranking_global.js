var classsrc_1_1_capa_domini_1_1_controladors_1_1_ctrl_ranking_global =
[
    [ "CtrlRankingGlobal", "classsrc_1_1_capa_domini_1_1_controladors_1_1_ctrl_ranking_global.html#a52c10f8d3687f147de37640912b63a99", null ],
    [ "afegirUsuariNou", "classsrc_1_1_capa_domini_1_1_controladors_1_1_ctrl_ranking_global.html#aeaba262a73e40aeb79af6dc9cbeffe84", null ],
    [ "getMillorsUsuarisGlobal", "classsrc_1_1_capa_domini_1_1_controladors_1_1_ctrl_ranking_global.html#a7e5e295bf0847d41e23dc74b3d2c5405", null ],
    [ "getRankingPerOrdreAlfabetic", "classsrc_1_1_capa_domini_1_1_controladors_1_1_ctrl_ranking_global.html#a4503ec55460151de898049186b5fc902", null ],
    [ "sumarPuntuacioAUsuari", "classsrc_1_1_capa_domini_1_1_controladors_1_1_ctrl_ranking_global.html#a456f1bbb0f1e03857ea426dd1edf979e", null ],
    [ "treureUsuari", "classsrc_1_1_capa_domini_1_1_controladors_1_1_ctrl_ranking_global.html#aaf0107d804635f75749391850e984e5f", null ],
    [ "cp", "classsrc_1_1_capa_domini_1_1_controladors_1_1_ctrl_ranking_global.html#a60d0f4c50f77aa50ee96323e4931d35b", null ],
    [ "RG", "classsrc_1_1_capa_domini_1_1_controladors_1_1_ctrl_ranking_global.html#af7bffc1682871a460cff6aa4c1f66887", null ]
];